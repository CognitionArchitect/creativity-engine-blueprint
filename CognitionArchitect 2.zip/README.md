# CognitionArchitect
A cognitive architecture designed to simulate creativity as a data compression-adaptation mechanism.