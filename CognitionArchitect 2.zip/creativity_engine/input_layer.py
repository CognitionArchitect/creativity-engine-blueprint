class InputLayer:
    def receive(self, raw_data):
        """Accept raw sensory data (text, image paths, audio paths)"""
        return raw_data
