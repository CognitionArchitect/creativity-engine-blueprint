class OutputLayer:
    def produce(self, concept):
        print("Final Output:", concept)
