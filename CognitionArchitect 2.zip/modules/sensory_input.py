# Sensory input interface

def process_input(signal):
    pass