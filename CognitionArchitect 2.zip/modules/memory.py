# Memory module

def store(data):
    pass

def retrieve(query):
    pass